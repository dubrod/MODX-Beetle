<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'enduser_option_merge' => NULL,
    'enduser_install_action_default' => 'merge',
    'enduser_option_samplecontent' => NULL,
    'enduser_install_samplecontent_default' => 'yes',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '436e49129dc9d030946135fcf1d620b2',
      'native_key' => '436e49129dc9d030946135fcf1d620b2',
      'filename' => 'xPDOFileVehicle/a451ae83ef28c3e2094e52e156bb27fb.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '63905f153d3da03e95dd0f19aa6c77e8',
      'native_key' => '63905f153d3da03e95dd0f19aa6c77e8',
      'filename' => 'xPDOFileVehicle/d420307055cc5938d9732f8121902f86.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25a250603fd6c4cbdda2f686567d1154',
      'native_key' => 'extension_packages',
      'filename' => 'modSystemSetting/67b53380f73365514a38fb5d63f4b250.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'cd4333d8000087796f35ea3aaf2b8895',
      'native_key' => 1,
      'filename' => 'modChunk/8c9a09cd9586fbfdc9af8c6d11fce864.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '29554afb7072b09fefa55f351cc77b8a',
      'native_key' => 2,
      'filename' => 'modChunk/7e9279165ca5feac3c4257f0d8d6efe2.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '9b283ead86c28ece3f032c8eb8071ffa',
      'native_key' => 23,
      'filename' => 'modChunk/45429bc8e8c6e351f3ce59728e1fa1af.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'd0de673bd74bfd16d605847d4c7bb633',
      'native_key' => 24,
      'filename' => 'modChunk/64e4f70972281e6c16d561d6e5903955.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '1e94df9cb0dd031c29ade1c5cc769216',
      'native_key' => 42,
      'filename' => 'modChunk/15937be3d57c8e56863c3d95303b6fdb.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'b2ede52c928572ec371cf90c5712f939',
      'native_key' => 43,
      'filename' => 'modChunk/2ac11062773e61cd04a479d337ff1aad.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'ea3090c68d57943db0083bdbae9c656d',
      'native_key' => 44,
      'filename' => 'modChunk/39a4e9648b93a949f42e3197ebc0d414.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '340612360061006e5c7033a4d6b4a570',
      'native_key' => 3,
      'filename' => 'modChunk/b4141b629f29caec67e180505fca0aeb.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '29d0887284d7b721229ea01acf00a17f',
      'native_key' => 19,
      'filename' => 'modChunk/37bdfc2b539384396620ae47437d16d6.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '798ad27c9043f15a89441ec84e0efbac',
      'native_key' => 4,
      'filename' => 'modChunk/d06001fddcac128350dee1a6a008363a.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '62f89cdba7249aa3792fde0021456d41',
      'native_key' => 21,
      'filename' => 'modChunk/88fa51fba9219fe5dc8528e4d922b8d9.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '81dd7e79e8e5b9d1561af752fc5357a1',
      'native_key' => 41,
      'filename' => 'modChunk/34d4fabdaac6e6280c11fcc7740b4fe6.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'edf29489a4a51668fc763bef80c6a38d',
      'native_key' => 22,
      'filename' => 'modChunk/5c7e9cd66a1d5e46fa69af6b24115640.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '7c86e86df9759414f8a94c940faeac19',
      'native_key' => 15,
      'filename' => 'modChunk/15fb9d6e80812d629dfd4e63945d9458.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '5a567711acd346b66bca5f9603ea7394',
      'native_key' => 16,
      'filename' => 'modChunk/077fcebdafb328bc0bbfcfffb3c5bdeb.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '56b95fff935a357461891dd96f7b454c',
      'native_key' => 5,
      'filename' => 'modChunk/c67732a811ba078a082cff2f7b9910bb.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '66123af5d14d825dd4001e97b0e9016a',
      'native_key' => 6,
      'filename' => 'modChunk/be64070fe84133f485bed0f45c1485d0.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '4c87f6fc13f3a0b7e5b65acbe5cc4094',
      'native_key' => 7,
      'filename' => 'modChunk/1ee11002d7ebc876cd36e801e88d83b3.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '21eaaf2228b2653c9dc7980b258d595e',
      'native_key' => 8,
      'filename' => 'modChunk/7ef018a6004173e0d5eb2c8580cb5d91.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'aa5126231d7b69237b4e2772491802b5',
      'native_key' => 9,
      'filename' => 'modChunk/f0c8282f992faf567f866b2324ac1624.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '84bf0a11202ecda8332a03df6b0bbd46',
      'native_key' => 34,
      'filename' => 'modChunk/d7abfcbb6340d1386804e79b897923d1.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '71598353c6e230159b1085e843493ba6',
      'native_key' => 10,
      'filename' => 'modChunk/8d6131f0ad529b64783df564cef52dfe.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'b321a64b965f4a4cf3178478c612dc01',
      'native_key' => 17,
      'filename' => 'modChunk/b574c88c83728e38336fc1f5a6bea8ad.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'fa57cb384baa3de0457bc8dd0e95a20f',
      'native_key' => 11,
      'filename' => 'modChunk/c3364284f0e5790e7ebaf833af774b6c.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '2a901eaf854872316848fed7cdfff209',
      'native_key' => 12,
      'filename' => 'modChunk/568a979393fa80c6fa856f091cc2bcce.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '7789095396e52dbc5dce8983fb665049',
      'native_key' => 13,
      'filename' => 'modChunk/8b8506b192eb50e7f41c2f391d16d4c1.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'efdf254e39a905ac8edc296b0c3a47d2',
      'native_key' => 14,
      'filename' => 'modChunk/5d0716d2c468a3c0cc358cac453386b6.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '211088d0ec9e7a2c571d531db9d98a17',
      'native_key' => 18,
      'filename' => 'modChunk/8eb3f00f7783c6d175920ff5635cec6b.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'f13978fdb8d58f2fb1f2f737eaf522a5',
      'native_key' => 20,
      'filename' => 'modChunk/da9d0c9bda07df37ec7bf8abebff390b.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '874f05bbe429662c7508a88e782f3060',
      'native_key' => 40,
      'filename' => 'modChunk/901494e8d96faa1f16ed97bc3361e146.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'db7e4050066e5d59973fd235adb3a2b6',
      'native_key' => 25,
      'filename' => 'modChunk/6869929da2681114e759478195f8fe34.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '91a279c3f863e855a029305e5872ebaf',
      'native_key' => 26,
      'filename' => 'modChunk/d94028fdf849c4a5a82b69a4087aa5d8.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'c29e6822d3e67af2598c48811dc417b5',
      'native_key' => 27,
      'filename' => 'modChunk/8669f7fb50440a97f4910bc2a43d0488.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '35bbd2847905bba4cc7e16c30d1bf1c1',
      'native_key' => 28,
      'filename' => 'modChunk/629c3a01e72828a6dfac8244baa21cb6.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'ce42b6fcb2eb34f136300228f85b2f92',
      'native_key' => 32,
      'filename' => 'modChunk/34df0a35f71ba3d9a653e619c10f4438.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '19614547834d746c01cf52f6f47c6780',
      'native_key' => 30,
      'filename' => 'modChunk/cf930044346ddb3587b9ff358483b309.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '4da0ba7c56b6381003623ae2f56ae1b0',
      'native_key' => 29,
      'filename' => 'modChunk/c39ca169255a1540f1b6e36ab81dfd13.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '4e29b5b4815048d32382206895b9645f',
      'native_key' => 31,
      'filename' => 'modChunk/ce006e804b9f83ea611e19e14b288994.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '31772fde5dfa3d738b3d91aff8c23d4a',
      'native_key' => 36,
      'filename' => 'modChunk/4014fd76db014820e159ebed303665b9.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '40dce1276894290dba27fd1773a4829c',
      'native_key' => 33,
      'filename' => 'modChunk/5767310ca340f7a43a18affc5da87f49.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'd524ee9271f7943daeeff98a80e6c675',
      'native_key' => 35,
      'filename' => 'modChunk/11459dd6e76393cb738785d95a89bf33.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '89f348bd5f336b1362bca12ce6dece36',
      'native_key' => 39,
      'filename' => 'modChunk/e97dec5cb98985e57e246f208bd6ac0d.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'b918fb17cb11ec2d0a5cfeb29e7fe87b',
      'native_key' => 45,
      'filename' => 'modChunk/47ad9f9d935ffde58b7a2d3ff11a1a1b.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '51707915f3410123b96e61a67dc4426f',
      'native_key' => 37,
      'filename' => 'modChunk/6f5f810ab3a12ea322563d8643a18e93.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '9086927c185a797bee34b9f55c61df65',
      'native_key' => 38,
      'filename' => 'modChunk/634652882ef40425aaf076218cde2f12.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'fd5f44cb28cf9f9435b80c95aa651227',
      'native_key' => 46,
      'filename' => 'modChunk/769c5c63859dd0b78b1a0159ac31c1da.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '66420e092d33f2843aba7f4a2d2a5e1b',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'theme',
      ),
      'filename' => 'modContextSetting/6a4a49190d45bc712447955d5dac8bda.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '0ce26e13916a31a7813fb15e4931688d',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'site_logo',
      ),
      'filename' => 'modContextSetting/e8b5802eca79097fb2663e2e1350df43.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '4c5152c2c9bd35ab29f492de9a73f8d2',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'default_theme_img',
      ),
      'filename' => 'modContextSetting/c184a154c1e671af7f29ed7362a4787f.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'd2c9066769f02b8095120356357a415d',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'default_carousel',
      ),
      'filename' => 'modContextSetting/13ab44a8082c1700f28938cc0f8a4595.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '3ad39ca926375f237f8a87633c2e7667',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'default_fposts',
      ),
      'filename' => 'modContextSetting/5def07597fed8cdee26170f31fc235ae.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '341007fe31eb2035ac8af563fddfab17',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'default_slogan',
      ),
      'filename' => 'modContextSetting/a82e50b4f70cf949853fbb49cdc0d4c8.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '74d7ec376f26f3d280b7d742a2815576',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'default_copyright',
      ),
      'filename' => 'modContextSetting/ed415d8718da707fc574ed03fc81d6cc.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '1227eb780961d43ee6cc24ec2d425f16',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'social_twitter',
      ),
      'filename' => 'modContextSetting/6bd3e8790547945e8669ed21b03cf4e7.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '9dd51a7d29a0c2c1388a4cd377972b56',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'social_facebook',
      ),
      'filename' => 'modContextSetting/467c52191a7261a6c1516320dac5f558.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'a51cc9abe55b1b39f92fc406cdf4bffb',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'default_slider',
      ),
      'filename' => 'modContextSetting/a762aeecc15b6a535c2925e0a96b7ae5.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'dd2cd705e5d4c957e6897dc0546ac53d',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'home_banner_msg',
      ),
      'filename' => 'modContextSetting/2117adfbfaf555f0f02c3155dc4711db.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '42d422f470319cdbfa12504adb54181b',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'home_banner_cta',
      ),
      'filename' => 'modContextSetting/a985ce3298925c0248f83349c1a80a52.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'bea7cb2a92961c18c31da816b8db7e01',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'home_banner_link',
      ),
      'filename' => 'modContextSetting/ba43f0a71512035a6535aace6a3606f4.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '2f9712efcaabe95b33c76373c5de5e0f',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'blog_id',
      ),
      'filename' => 'modContextSetting/68309a88fbbecda9cc738a6a70d21999.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'd63decc2eefa0c7e862fb5e86ef91018',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'archive_id',
      ),
      'filename' => 'modContextSetting/aa925d6b6d4784cbe21044880b3620b5.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'ed70ac84128f6c4cab18b7965bab2b30',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'menu_id',
      ),
      'filename' => 'modContextSetting/0ae3655e5101ed779f3199738552aa49.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modFormCustomizationProfile',
      'guid' => 'c701b8d66d05f5f4b98d2fdfaf761239',
      'native_key' => 1,
      'filename' => 'modFormCustomizationProfile/1e161498982f7e5f26259ed839798624.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => 'f9292e8ba10bdad5e6bc32a22e639b84',
      'native_key' => 8,
      'filename' => 'modSnippet/dbb500e6bdfb678aca5cf2ddff2d3c39.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => 'a5ee20acc433c105fdb07d1cdd1c8a11',
      'native_key' => 2,
      'filename' => 'modTemplate/4813e4eb3a65c9edc34cf46f9c9e41b2.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => '77b178324b62c83b82aab5222e119d0c',
      'native_key' => 3,
      'filename' => 'modTemplate/5d554d6330cdc80e32b86a73dd2bc7cc.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'd53b6efcbb0f509b631de524079b2619',
      'native_key' => 'd53b6efcbb0f509b631de524079b2619',
      'filename' => 'xPDOScriptVehicle/bd0ecf5f1a089a5f418803638b310457.vehicle',
    ),
  ),
);