<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'enduser_option_merge' => NULL,
    'enduser_install_action_default' => 'merge',
    'enduser_option_samplecontent' => NULL,
    'enduser_install_samplecontent_default' => 'yes',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '666c13c76493b5a828496e34b09b1bb0',
      'native_key' => '666c13c76493b5a828496e34b09b1bb0',
      'filename' => 'xPDOFileVehicle/e5e13d6832efb4459949a62874b641cc.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'ab5a2429b35fae8a345454b7bc7f5a44',
      'native_key' => 'ab5a2429b35fae8a345454b7bc7f5a44',
      'filename' => 'xPDOFileVehicle/3b0630b7c96ace530176c6bec86ea4cb.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a4b026aab51413d89b99027595ac8a2',
      'native_key' => 'extension_packages',
      'filename' => 'modSystemSetting/7724882cc687e49cf1e315305195b2ec.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'a14d60d10c6b67881636307c14df4970',
      'native_key' => 1,
      'filename' => 'modChunk/0206792f64096968e36bf5c4cdac9b96.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '8ee2a8e302d56340ae11f06a2bf6411c',
      'native_key' => 2,
      'filename' => 'modChunk/7ab5832df4608fbcdbf7b427031b3849.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'e4b26d69e29a4e2f9aff964d2af6fd25',
      'native_key' => 23,
      'filename' => 'modChunk/8d2c62b34f67773f3e32ff4239260850.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '21f4d5dbcf59b3f34cf22784d6b155f0',
      'native_key' => 24,
      'filename' => 'modChunk/bfb1596c6376c7715e8da046ef45736a.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '6faeb7eab32c68547f4a254eeada220e',
      'native_key' => 42,
      'filename' => 'modChunk/8dd24e673cbfdb523af7a60c7f578991.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '1c5a74db0d1b52437a3d4aa3a2652504',
      'native_key' => 43,
      'filename' => 'modChunk/579f008b020806e310d26f65a3a34551.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '93fe1789ab1b2f1426a855e3c9c4a3c4',
      'native_key' => 44,
      'filename' => 'modChunk/72b0fa88e93aa543bf1b2b2fdeafe217.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '12f8e44dd6edc760735bc06daeff95ed',
      'native_key' => 3,
      'filename' => 'modChunk/b23fb819e106fed38416d7bdd9e10969.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'cb4a16e034af6f6432542a289bddca30',
      'native_key' => 19,
      'filename' => 'modChunk/00fd2d4983fa37a798f218ba2f4555f1.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'bc8f33fd39cc7b451572966759b696aa',
      'native_key' => 4,
      'filename' => 'modChunk/13bf0438c883a350ea3d354d685f2209.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '267388cfb8eaacde952b0379ba46510f',
      'native_key' => 21,
      'filename' => 'modChunk/334f25451e4620d14a017adcdbdd46fb.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'dc11051919bcd52e9e03956868526552',
      'native_key' => 41,
      'filename' => 'modChunk/ec34e6a7cd33f8cfa53df5802dab99ea.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'd6b5c8769b797c2fbffcaa6ed8c69a83',
      'native_key' => 22,
      'filename' => 'modChunk/1b1a3898e05ae6780f9106e3925310d0.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '34d98f22d92b9d2611639184ff5cba2c',
      'native_key' => 15,
      'filename' => 'modChunk/8b7913b60f24b5094b229158ec00c767.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'a68e5c6ef0822110e9a1611e72c8b447',
      'native_key' => 16,
      'filename' => 'modChunk/3059c6d83f50e20dfb10c734ce4e5ca8.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '4f86cdebb9cba6bfc2e7ee75cfe0803c',
      'native_key' => 5,
      'filename' => 'modChunk/3615beb44924ab5add9a31ed907106ee.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '3b0d197191cd850fc7f43454d9347969',
      'native_key' => 6,
      'filename' => 'modChunk/15cc4b65d37f9e125630b99a5bb9ee76.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'f801c090690a5571da70727efc356c40',
      'native_key' => 7,
      'filename' => 'modChunk/7425dac17c99da12eefa895748a1abcb.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '1df3357d3467dd5045cf2e06d99b9c96',
      'native_key' => 8,
      'filename' => 'modChunk/531f42de1aee291c220016f32e763939.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'a2b550e4ace086389bed53a110b8ebe9',
      'native_key' => 9,
      'filename' => 'modChunk/265955d7e9a78c5eeeecbf081b55da27.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '77e3928775b2c7f2b6aa18ec578628e5',
      'native_key' => 34,
      'filename' => 'modChunk/648b83290f752fd5fb9bad489c78b3a0.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '427380e5c72f46069e913bb7dbf8487b',
      'native_key' => 10,
      'filename' => 'modChunk/8cf19561ee66e6b72a3fd123e8a3dcd9.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '06e55f3e70ad8d66520ad18dd5710346',
      'native_key' => 17,
      'filename' => 'modChunk/b223d9d285b009ac4eac24465ae179d8.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'a7cb3d8f1ee4a30e1e9ab1b09c9c474c',
      'native_key' => 11,
      'filename' => 'modChunk/fb494069ed67a81dd7aa86e089f3f625.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'd841c840ff7ca3e46bc92f3093a6caeb',
      'native_key' => 12,
      'filename' => 'modChunk/03c71c9d814e7304b9467d1c056491e0.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '57292a0d8531dd1d2e02be5be222551f',
      'native_key' => 13,
      'filename' => 'modChunk/32ec5a0bdc733d3c82ecd21ba97627fa.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'c88fee371261829c8865afcd9766314a',
      'native_key' => 14,
      'filename' => 'modChunk/70d43aceb15aed574473f42248ac0d87.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'e0d9a7bd5bc585e1712e7187638bf867',
      'native_key' => 18,
      'filename' => 'modChunk/3773d796a2b279124936914594f7b21b.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '57e5610e40e3ac0e97145fadc47467e7',
      'native_key' => 20,
      'filename' => 'modChunk/b31a13685e0806c9c1ea9adbf06b15b0.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'f8f49295068ce51a314c1f46b3a03f0c',
      'native_key' => 40,
      'filename' => 'modChunk/f283c130fa192e20226044f718222013.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '0982c98b4269433a41c396d7b6ecec8a',
      'native_key' => 25,
      'filename' => 'modChunk/12ebb6893b7941bd6ea9af734c6a6a93.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '7d22c0cd8d99a7c9a6adb4ef161cdb87',
      'native_key' => 26,
      'filename' => 'modChunk/efac4dca92dba3bee07157a79d4878f6.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '49bc4b4c9050b7fc579528485a0ccf23',
      'native_key' => 27,
      'filename' => 'modChunk/3e0eab295965f353357a427c06692dc7.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'eb6a497b29fe7ead4bef5e79b6559ee5',
      'native_key' => 28,
      'filename' => 'modChunk/8c60bcb1502a1d279f2a3aaa2d82669a.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'a4f4d19fff7337ca0d8cfcc68bbda6d3',
      'native_key' => 32,
      'filename' => 'modChunk/59671e323d6d62bcb7fcce6c8be130b1.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'dd4d1fd3f5e62cb07fa621bb2d671e29',
      'native_key' => 30,
      'filename' => 'modChunk/b47f4c8f44ac508b2a13cd97de073085.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '35e81f244c9ab9ffb177a6f1c57d8e0f',
      'native_key' => 29,
      'filename' => 'modChunk/7797c9aa24df40633df111fcaeabdb88.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '511410a02582313bf3727bcd8451f18a',
      'native_key' => 31,
      'filename' => 'modChunk/167ad38dabab0d8b92a42e8c8a34949b.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'dcbec09cab019180af854b803944c58e',
      'native_key' => 36,
      'filename' => 'modChunk/d6751e960c97c37913c3e66cecc79e34.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '8378e03352f49c554470d957509b3130',
      'native_key' => 33,
      'filename' => 'modChunk/f8e3900ad90ec696a530eb98f94668c1.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '812607924930b55c478933503de78533',
      'native_key' => 35,
      'filename' => 'modChunk/1dfe111e7082cf48616221c4c03792f3.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'f7a5d81a3d9171c3eed32674752e8584',
      'native_key' => 39,
      'filename' => 'modChunk/10e00104c0743804c7e0045005a9e4e0.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '092659ec726e71af36622b1b57d99731',
      'native_key' => 45,
      'filename' => 'modChunk/58171d61ec8226b96b3808a960c9401a.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => 'faf4c7759989bbf91ea187433fa23e11',
      'native_key' => 37,
      'filename' => 'modChunk/f2f7d3fdc94668b7b0998e50753951f8.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '107c6570099d6d3cfa21853f2944c3c9',
      'native_key' => 38,
      'filename' => 'modChunk/12ec04775c5fe8f1c60f338f6ba72d1d.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modChunk',
      'guid' => '9798cf424f33c8c9d5f8bedc32eef5ab',
      'native_key' => 46,
      'filename' => 'modChunk/b1d1f47fc8a81a89537cdb6b18904f35.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'd0524fc791dacad50beec89e3f3e9805',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'theme',
      ),
      'filename' => 'modContextSetting/ef21c81e5734ca9521ced26ccf3a02e6.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '18e570a9275b4f14a5161cb53e2c0c3b',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'site_logo',
      ),
      'filename' => 'modContextSetting/d1a03dd93dfd81cb7807bdf92509a58f.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'a4673bfb231159f3318321d5c58434d3',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'default_theme_img',
      ),
      'filename' => 'modContextSetting/3d8c808b27898ff8bf4bda0d27c8f7e4.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '3ecea85b14171cdec99b7dffdf6b661b',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'default_carousel',
      ),
      'filename' => 'modContextSetting/918e137b3c0edad1b9d18a6cf9acabb2.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '07c079898a0498e89880054ae2420357',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'default_fposts',
      ),
      'filename' => 'modContextSetting/26cd2a24417c0215469b95733a50a55d.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '7c3efb7a78a5e33adf3f3494227ad066',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'default_slogan',
      ),
      'filename' => 'modContextSetting/8a49b201dfc46b5a92c71dc3dc55c919.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '007fea27f975eac083043f573e3f2663',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'default_copyright',
      ),
      'filename' => 'modContextSetting/6761ba389c2cf6554de87195565f18af.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '6d2512963ebef9341df9d8f2cf2ae163',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'social_twitter',
      ),
      'filename' => 'modContextSetting/b7882f6e66cabdbd1d6a8733a1db25e3.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'effb5c2ab05ff0cd989586ac61a0f23a',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'social_facebook',
      ),
      'filename' => 'modContextSetting/17884d5f2990bf661b69e4181808781c.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '78030074043859ccc029a2bf0986f683',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'default_slider',
      ),
      'filename' => 'modContextSetting/f3e231c503943f36c7e5f36763a173e5.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '3fd0405670d2059c3ccf9b2ce6943c23',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'home_banner_msg',
      ),
      'filename' => 'modContextSetting/c04df8dcca9c06ed57a3a037b937527e.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '5c16218d22832de3055d96000e730911',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'home_banner_cta',
      ),
      'filename' => 'modContextSetting/fa32116984c2ac4d0c1251ccf01d5643.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '3f42b49f04b1a544fdf278346e40bef4',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'home_banner_link',
      ),
      'filename' => 'modContextSetting/73b5d5441931c6b65f14f0b2637a0ae3.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '1754e02e1bc4a45512bb4e42dd53b13e',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'blog_id',
      ),
      'filename' => 'modContextSetting/665e34a941c3ad9ce6fbc1bda863e6a1.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '85a06a29d8ae76a8280a5b663a9ded45',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'archive_id',
      ),
      'filename' => 'modContextSetting/5b0b3d286316116466aad7581f3eb92c.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '618fb459d5a8ea4ba03402705f318b37',
      'native_key' => 
      array (
        0 => 'web',
        1 => 'menu_id',
      ),
      'filename' => 'modContextSetting/efbc5ec8e4be8efa0c1a935fe5d8dcb6.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modFormCustomizationProfile',
      'guid' => 'd4266c5a82f435ec3d1245dd53bddaf5',
      'native_key' => 1,
      'filename' => 'modFormCustomizationProfile/d90dfa40f61b70657299c223991a2461.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '220c61575a7534cd8812f94ad1d120d0',
      'native_key' => 8,
      'filename' => 'modSnippet/c04a03a05eb04011e472c45fe3adf460.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => 'c7c0326191733b3dc6c8dc62bf8bedde',
      'native_key' => 2,
      'filename' => 'modTemplate/fc9e15fdceca8b6f1bb7f0e7803885e8.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTemplate',
      'guid' => 'fbdfd47b58d41f1d3d68292819cad9bf',
      'native_key' => 3,
      'filename' => 'modTemplate/c747c87fe9356308155b68d11e740848.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '591a604020071bed1a4556447df88a56',
      'native_key' => '591a604020071bed1a4556447df88a56',
      'filename' => 'xPDOScriptVehicle/bd2ea8c745e37a07992f388ada6b1ac4.vehicle',
    ),
  ),
);